player_health = 100 
enemy_health = 50
import random
print ("your health is", player_health)
if player_health <= 0:
    print("YOU LOSE")

print("A goblin is approaching you what do you do")
print("the goblin has", enemy_health)

attack = input("what attack do you want to use?\n"
            "A: Sword attack 25 damage\n"
            "B: brute attack 15 damage\n"
            "C:weak ahh attack 1.5 damage\n")
if attack == "A":
  dodge = random.randint(1, 100)
  if dodge <= 20:
    print("goblin dodged your weak ahh attack you noob")
  else:
    print("You attacked the goblin for 25 hp")
    enemy_health -= 25
    print("goblin health is now", enemy_health)
elif attack == "B":
  dodge = random.randint(1, 100)
  if dodge <= 20:
    print("skill issue goblin dodged your weak ahh attack noob")
  else:
    print("You attacked ts nga for 15 hp") 
    enemy_health -= 15 
    print("goblin health is now", enemy_health)
elif attack == "C":
  
  print("whyd you choose this as a punishment here you go")
  player_health-= 99999999999 

  
  print("heres your gift", player_health ,"this is your health now")
elif attack == "smell and lick his feet":
  print("OUUUU SHIII")
  player_health += 190000000900
  print("Your health is now", player_health)
if player_health <= 0:
  print("fuh off you nga boi")
print("goblins turn to eat your feet boiiiii")
one_shot = random.randint(1, 100)
if one_shot == 1:
  print("Unlucky ahh mofo the goblin one shotted you 1/100 chance btw")
  player_health = 0
elif one_shot <= 5:
  print("you almost died lil bro")
  player_health -= 45
  print("your health is now", player_health)
elif one_shot <= 10:
  print("oooo he hit your weak ahh for 40 hp ")
  player_health -= 40
  print("your weak ahh health is now", player_health)
else:
  print("Goblin hit you for 10 health")
  player_health -= 10
  print("your health is now", player_health)
if player_health <= 0:
  print("YOU LOSE NOOBY BOÎiiiiiiiiiiiiiii")
if player_health <=0:
  exit()
print("its ur turn again nga")
attack2 = input("Your tired but can still fight what do you do?\n"
               "A:Sword attack 10 hp\n"
               "B:Brute attack 7 hp\n"
               "C:Fire ball 15hp\n")
insane_chance = random.randint(1,100)
if insane_chance == 1:
  print("no way the gods blessed you, you oneshotted the goblin")
  enemy_health = 0
  print("you win lmao")
if enemy_health == 0:
  exit()
else:
      dodge = random.randint(1, 100)
      if dodge <= 20:
        print("he dodged your attack")
      else:
          if attack2 == "A":
            print("you hit the goblin for 10 hp")
            enemy_health -= 10
            print("goblin health is now", enemy_health)
          elif attack2 == "B":
            print("YOU HIT HIM FOR 7 HP GRRR IM MAD DEV IS MAD WHILE CODING THIS I WANT TO RIP THAT GOBLIN APART")
            enemy_health -= 7
            print("GOBLIN HEALTH IS", enemy_health,"IM GONNA RIP HIM APART MYSELF")
          elif attack2 == "C":
            print("since dev is so happy ill give you 1 extra damage")
            print("you dealt 16 hp")
            enemy_health -= 16
            print("goblin health is now", enemy_health)
          elif attack2 == "wowie zowie secret secret here i am my balls are steel":
            print("wowie zowie man with balls of steel here you go king")
            player_health += 1000000000000000
            print("your health is now", player_health)
          if enemy_health <= 0:
            print("you win wohoooo")
            exit()
          else:
            one_shot = random.randint(1, 100)
              if one_shot == 1:
              print("Unlucky ahh mofo the goblin one shotted you 1/100 chance btw")
              player_health = 0
              elif one_shot <= 5:
              print("you almost died lil bro")
              player_health -= 45
              print("your health is now", player_health)
              elif one_shot <= 10:
              print("oooo he hit your weak ahh for 40 hp ")
              player_health -= 40
              print("your weak ahh health is now", player_health)
              else:
                print("Goblin hit you for 10 health")
                player_health -= 10
                print("your health is now", player_health)
                if player_health <= 0:
                print("YOU LOSE NOOBY BOÎiiiiiiiiiiiiiii")
                if player_health <=0:
                exit()
                elif enemy_health <= 0:
                  print("YIPPIEE YOU WIN")
                elif enemy_health <= 0:
                  exit()
              else:
                print("you and the goblin realized you love eachother and got married and had 3 kids and lived happily everafter")
                print("but then you got home and saw that the lamp looked a bit werid.....")
                exit()
